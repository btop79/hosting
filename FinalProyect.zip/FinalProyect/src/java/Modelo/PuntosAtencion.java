
package Modelo;

public class PuntosAtencion {
    int id;
    String nombrePa;
    String region;
    String estadoPa;

    public PuntosAtencion(int id,String nombrePa, String region, String estadoPa) {
        this.id = id;
        this.nombrePa = nombrePa;
        this.region = region;
        this.estadoPa = estadoPa;
    }

    public PuntosAtencion() { //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getNombrePa() {
        return nombrePa;
    }

    public void setNombrePa(String nombrePa) {
        this.nombrePa = nombrePa;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String nombreRegion) {
        this.region = nombreRegion;
    }

    public String getEstadoPa() {
        return estadoPa;
    }

    public void setEstadoPa(String estadoPa) {
        this.estadoPa = estadoPa;
    }
    
}
