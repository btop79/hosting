
package Modelo;


public class Empleado {
    int dpi;
    String region;
    String punto;
    String nombre;
    String correo;
    String rol;
    String cargo;
    String estado;
    String user;
    String password;
    
    
    public Empleado(){
    }

    public Empleado(int dpi, String region, String punto, String nombre, String correo, String rol, String cargo, String estado, String user, String password) {
        this.dpi = dpi;
        this.region = region;
        this.punto = punto;
        this.nombre = nombre;
        this.correo = correo;
        this.rol = rol;
        this.cargo = cargo;
        this.estado = estado;
        this.user = user;
        this.password = password;
    }

    public int getDpi() {
        return dpi;
    }

    public void setDpi(int dpi) {
        this.dpi = dpi;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getPunto() {
        return punto;
    }

    public void setPunto(String punto) {
        this.punto = punto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
