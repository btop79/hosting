
package Modelo;


public class TiposQuejas {
    String siglas;
    String des;
    String estado;

    public TiposQuejas() {
    }

    public TiposQuejas(String siglas, String des, String estado) {
        this.siglas = siglas;
        this.des = des;
        this.estado = estado;
    }

    public String getSiglas() {
        return siglas;
    }

    public void setSiglas(String siglas) {
        this.siglas = siglas;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
}
