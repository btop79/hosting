
package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmpleadoDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    public Empleado validar(String user, String password){
        Empleado em = new Empleado();
        
        String sql = "select FROM Usuario where Usuario=? and Contraseña=?";
        
        try{
            con = cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, password);
            rs=ps.executeQuery();
            
            while(rs.next()){
                em.setRegion(rs.getString("NombreRegion"));
                em.setPunto(rs.getString("NombrePA"));
                em.setDpi(rs.getInt("Dpi"));
                em.setNombre(rs.getString("Nombres"));
                em.setCorreo(rs.getString("Email"));
                em.setRol(rs.getString(1));
                em.setCargo(rs.getString("Cargo"));
                em.setEstado(rs.getString("Estado"));
                em.setUser(rs.getString(2));
                em.setPassword(rs.getString(3));
            }
        } catch(Exception e){
            System.err.println("Error" +e);
        }
        return em;
    }
    
}
