
package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class TiposQuejasDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public List listar(){
        String sql="selec * from tipoqueja";
        List<TiposQuejas>lista= new ArrayList<>();
        try{
            con= cn.Conexion();
            ps=con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                TiposQuejas tq=new TiposQuejas();
                tq.setSiglas(rs.getString(1));
                tq.setDes(rs.getString(2));
                tq.setEstado(rs.getString(3));
                lista.add(tq);
            }
        } catch(Exception e){
            
        }
        return lista;
    }
    
    public int agregar(TiposQuejas tq){
        String sql="insert into tipoqueja(Siglas, Descripcion, Estado) values(?, ?, ?)";
        try{
            con= cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, tq.getSiglas());
            ps.setString(2, tq.getDes());
            ps.setString(3, tq.getEstado());
            ps.executeUpdate();
        } catch (Exception e){
            
        }
        return r;
    }
    
    public TiposQuejas listarId(String siglas){
        TiposQuejas tq=new TiposQuejas();
        String sql="select * from  where Siglas =" + siglas;
        try{
          con = cn.Conexion();
          ps= con.prepareStatement(sql);
          rs=ps.executeQuery();
          while(rs.next()){
              tq.setSiglas(rs.getString(1));
              tq.setDes(rs.getString(2));
              tq.setEstado(rs.getString(3));
              
          }
        } catch(Exception e){
            
        }
        return tq;
    }
    
    public int actualizar(TiposQuejas tq){
        String sql="update tipoqueja set Siglas=?, Descripcion=?, Estado=?";
        try{
            con= cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, tq.getSiglas());
            ps.setString(2, tq.getDes());
            ps.setString(3, tq.getEstado());
            ps.executeUpdate();
        } catch (Exception e){
            
        }
        return r;
        
    }
    
}
