
package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class PuntosAtencionDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    PuntosAtencion pa=new PuntosAtencion(); 
    int r;
    
    
    public List listar(){
        String sql="selec * from puntosatencion";
        List<PuntosAtencion>lista= new ArrayList<>();
        try{
            con= cn.Conexion();
            ps=con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                PuntosAtencion pa = new PuntosAtencion();
                pa.setId(rs.getInt(1));
                pa.setRegion(rs.getString(2));
                pa.setNombrePa(rs.getString(3));
                pa.setEstadoPa(rs.getString(4));
                lista.add(pa);
            }
        } catch(Exception e){
            
        }
        return lista;
    }
    
    public int agregar(PuntosAtencion pa){
        String sql="insert into puntosatencion(Region, NombrePA, Estado) values(?, ?, ?)";
        try{
            con= cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, pa.getRegion());
            ps.setString(2, pa.getNombrePa());
            ps.setString(3, pa.getEstadoPa());
            ps.executeUpdate();
        } catch (Exception e){
            
        }
        return r;
    }
    
    public PuntosAtencion listarId(int id){
        PuntosAtencion pa = new PuntosAtencion();
        String sql="select * from puntosatencion where IdPA =" + id;
        try{
          con = cn.Conexion();
          ps= con.prepareStatement(sql);
          rs=ps.executeQuery();
          while(rs.next()){
              pa.setRegion(rs.getString(2));
              pa.setNombrePa(rs.getString(3));
              pa.setEstadoPa(rs.getString(4));
              
          }
        } catch(Exception e){
            
        }
        return pa;
    }
    
    public int actualizar(PuntosAtencion pa){
        String sql="update puntosatencion set Region=?, NombrePA=?, Estado=? where IdPA=?";
        try{
            con= cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, pa.getRegion());
            ps.setString(2, pa.getNombrePa());
            ps.setString(3, pa.getEstadoPa());
            ps.setInt(4,pa.getId());
            ps.executeUpdate();
        } catch (Exception e){
            
        }
        return r;
        
    }

}
