
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class Conexion {
    Connection con;
    //Metodo para conectar el proyecto a la base de datos.
    public Connection Conexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3308/finalproyect_sq?useTimezone=true&serverTimezone=UTC",
                    "root","");
        }catch(Exception e){
            System.err.println("Error" +e);
        }
        return con;
    }
    
   /*  Connection con;
    //Metodo para conectar el proyecto a la base de datos.
    public Conexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3308/finalproyect_sq?useTimezone=true&serverTimezone=UTC",
                    "root","");
        }catch(Exception e){
            System.err.println("Error" +e);
        }
    
    }
     public static void main(String[] args) {
        Conexion cn=new Conexion();
      Statement st;
        ResultSet rs;
       try {
           st=cn.con.createStatement();
           rs=st.executeQuery("select * from region");
        while (rs.next()){
                System.out.println(rs.getInt("IdRegion")+" " +rs.getString("NombreRegion"));
             }
            cn.con.close();
        } catch (Exception e) {
        }
       
    }*/
    
}
